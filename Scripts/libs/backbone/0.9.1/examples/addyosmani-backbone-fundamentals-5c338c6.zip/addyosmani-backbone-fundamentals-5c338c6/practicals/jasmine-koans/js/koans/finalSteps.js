describe('Bringing It All Together', function() {
    
});
define( ['backbone'],
        function( Backbone ) {
            // Using ECMAScript 5 strict mode during development. By default r.js will ignore that.
            "use strict";

            var ResultEntry = Backbone.Model.extend( {
            } );

            return ResultEntry;
        } );

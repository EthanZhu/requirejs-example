#!/bin/bash
npm install express
npm install mongodb --mongodb:native
npm install mongoose
npm install jade

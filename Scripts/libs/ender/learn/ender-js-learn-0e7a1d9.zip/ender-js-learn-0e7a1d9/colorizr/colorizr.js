!function (context) {
  function color(el, val) {
    el.style.color = val
  }
  context['color'] = color
}(this);
